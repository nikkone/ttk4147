/*
 * main.c
 *
 *  Created on: Oct 10, 2017
 *      Author: root
 */
#include <stdio.h>

int main(void){
	printf("Hello\n");
	return 0;
}
